# esx_moneywash
Money Wash script for FiveM
